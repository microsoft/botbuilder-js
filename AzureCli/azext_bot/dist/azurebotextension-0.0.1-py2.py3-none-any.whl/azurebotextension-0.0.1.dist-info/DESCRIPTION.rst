Microsoft Azure CLI 'bot service' Command Module


